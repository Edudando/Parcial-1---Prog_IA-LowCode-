# Poké Batalla

Batalla Pokémon por turnos contra la CPU. El **motor está escrito en Python** y corre en el
navegador gracias a **Pyodide** (Python compilado a WebAssembly). Los datos (stats, tipos,
movimientos, nombres en español, sprites y gritos) se traen **en vivo de PokeAPI**, así que se
puede elegir cualquiera de los **1025 Pokémon**.

Funciona de tres maneras, con el mismo motor:

| Modo | Cómo se arranca | Interfaz | Quién corre Python |
|---|---|---|---|
| **Escritorio** | `py -3.13 juego.py` | ventana de pygame, sin navegador | tu Python 3.13 |
| **Local** | `python servidor.py` | navegador | el Python de tu compu |
| **Web** | Cloudflare Pages o cualquier hosting estático | navegador | Pyodide, dentro del navegador |

La página detecta sola en qué modo está: si encuentra `servidor.py` usa tu Python y ni descarga
Pyodide; si no, carga Pyodide.

```
poke-batalla/
├── README.md
├── juego.py           <- modo escritorio: ventana con pygame
├── requirements.txt   <- pygame (solo para juego.py)
├── servidor.py        <- modo local: servidor con la biblioteca estándar, sin pip
└── public/            <- esta carpeta es lo que se publica
    ├── index.html     estructura de la página
    ├── style.css      estilos (modo claro/oscuro, responsive)
    ├── app.js         interfaz: carga Pyodide y llama a main.py
    ├── main.py        puente JS <-> Python (JSON) + simulador por consola
    ├── pokeapi.py     cliente de PokeAPI: descarga, caché, elección de movimientos, rival
    ├── battle.py      motor de batalla (no sabe nada de HTTP)
    └── _headers       cabeceras para Cloudflare Pages
```

## Cómo usa PokeAPI

| Endpoint | Para qué |
|---|---|
| `/pokemon-species/?limit=2000` | lista de los 1025 nombres para el buscador |
| `/pokemon/{id}` | stats base, tipos, sprites animados (Showdown), grito, movimientos que aprende |
| `/pokemon-species/{id}` | nombre en español |
| `/move/{id}` | nombre en español, tipo, poder, precisión, PP, prioridad y efectos (`meta`) |

- **Movimientos automáticos:** toma los que aprende por nivel en el juego más nuevo en que aparece
  (Escarlata/Púrpura, Espada/Escudo…). Si hay pocos o son poco variados, suma MT/tutor. Después elige
  4: el mejor ataque de cada tipo propio (STAB), luego cobertura de otros tipos, teniendo en cuenta
  si el Pokémon pega más fuerte físico o especial.
- **Efectos que salen de la API y el motor simula:** golpes múltiples (`min_hits`/`max_hits`),
  robo de vida y daño de retroceso (`drain`), crítico alto (`crit_rate`), parálisis, quemadura,
  veneno, sueño y congelación (`ailment` + `ailment_chance`), amedrentar (`flinch_chance`) y prioridad.
- **Rival equilibrado:** elige 3 Pokémon al azar con un total de stats base parecido al de tu equipo.
- **Caché:** guarda una versión compacta de cada respuesta en `localStorage`. La primera batalla
  hace ~150–250 pedidos; las siguientes con los mismos Pokémon, ninguno. (PokeAPI pide cachear en su
  política de uso justo.)
- **Respaldo:** si `pokeapi.co` no responde, usa solo el espejo oficial de GitHub
  (`PokeAPI/api-data`), que tiene los mismos datos.

## Juego de escritorio con pygame (Python 3.13)

Una ventana propia, sin navegador. Usa exactamente el mismo motor (`public/battle.py`) y el mismo
cliente de PokeAPI (`public/pokeapi.py`).

**Instalar (una sola vez):**
```bash
# Windows
py -3.13 -m pip install -r requirements.txt
# Linux / macOS
python3.13 -m pip install -r requirements.txt
```

**Jugar:**
```bash
py -3.13 juego.py        # Windows
python3.13 juego.py      # Linux / macOS
```

**Controles**

| Tecla / acción | Qué hace |
|---|---|
| Escribir + Enter | buscar un Pokémon por nombre o número (aparecen sugerencias; se pueden clickear) |
| Clic en una tarjeta | agregar / sacar del equipo (clic en la ficha de arriba también lo saca) |
| Rueda del mouse | ver más tarjetas si agregaste muchas |
| `1` a `4` | elegir ataque |
| `Tab` | pasar de "Luchar" a "Pokémon" (para cambiar) |
| `Espacio`, `Enter` o clic | adelantar el texto de la batalla |
| `M` | silenciar los gritos |
| `F11` | pantalla completa (la ventana también se puede agrandar) |
| `Esc` | volver a elegir equipo / salir |

- Sprites pixel art y gritos de PokeAPI; se guardan en `.cache_pokeapi/medios/`, así que la
  segunda vez abre sin descargar nada.
- La red corre en un hilo aparte: la ventana nunca se congela mientras baja datos.
- Si instalás **pygame-ce** en lugar de pygame (`pip install pygame-ce`), el juego lo detecta y
  muestra los sprites **animados**. No instales los dos a la vez: se pisan. pygame-ce es también
  la opción si algún día pasás a Python 3.14, porque el pygame clásico todavía no instala ahí.

## Correr en tu compu con Python 3.14 (modo local)

Solo necesitás Python 3.10 o más nuevo (probado con 3.14). No hay que instalar nada con pip.

```bash
cd poke-batalla
python servidor.py            # abre http://localhost:8000 en el navegador
python servidor.py 8080       # en otro puerto
python servidor.py --no-abrir # sin abrir el navegador
```
En Windows, si tenés varias versiones instaladas: `py -3.14 servidor.py`.

- Arriba de la página dice **"Python 3.14.x local"**: así confirmás que la batalla la corre tu Python.
- La caché de PokeAPI se guarda en `.cache_pokeapi/` (unos pocos MB, se puede borrar).
- Cada pestaña tiene su propia partida: otras personas de tu misma red wifi pueden entrar a
  `http://IP-DE-TU-COMPU:8000` y jugar (cada una contra la CPU). Si Windows pregunta por el
  firewall, permití el acceso en redes privadas.
- Para cortar: `Ctrl+C` en la terminal.

Abrir `index.html` con doble clic no funciona: el navegador bloquea la carga de los archivos.
Si querés probar el modo web (Pyodide) en tu compu, usá `cd public` y `python -m http.server 8000`.

Probar solo el motor por consola (usa PokeAPI de verdad):
```bash
cd public
python main.py                   # una batalla aleatoria con el log completo
python main.py 1 pikachu 6 gengar  # tu equipo, por nombre o número
python main.py 50                # 50 batallas y estadísticas
```

## Publicar gratis en Cloudflare Pages

### Opción A: arrastrar y soltar (lo más rápido)
1. Creá una cuenta en https://dash.cloudflare.com (gratis).
2. **Workers & Pages** → **Create** → pestaña **Pages** → **Upload assets**.
3. Poné un nombre (ej. `poke-batalla`) y arrastrá **la carpeta `public`**.
4. **Deploy**. Queda en `https://poke-batalla.pages.dev`.

### Opción B: conectado a GitHub (se actualiza solo con cada push)
1. Subí esta carpeta a un repo de GitHub.
2. **Workers & Pages** → **Create** → **Pages** → **Connect to Git** → elegí el repo.
3. Build: Framework preset **None**, Build command *(vacío)*, Build output directory **`public`**.
4. **Save and Deploy**.

### Opción C: por terminal con Wrangler
```bash
npx wrangler login
npx wrangler pages deploy public --project-name poke-batalla
```

## Personalizar

- **Destacados de la pantalla inicial:** array `DESTACADOS` en `app.js` (números de Pokédex).
- **Tamaño del equipo:** `TAM_EQUIPO` en `app.js` (hasta 6).
- **Movimientos que no se usan:** set `EXCLUIDOS` en `pokeapi.py` (los que el motor no simula,
  como Rayo Solar o Hiperrayo, que necesitan cargar o recargar un turno).
- Si cambiás el formato de lo que se guarda en caché, subí `VERSION_CACHE` en `pokeapi.py`.

## Ideas para seguir

- Movimientos de estado (Danza Espada, Toxic, Protección) y cambios de stats.
- Habilidades (`/ability/{id}`) y objetos.
- Multijugador en tiempo real con Cloudflare Workers + Durable Objects.

---
Proyecto de fans sin fines de lucro. Pokémon © Nintendo / Game Freak / The Pokémon Company.
