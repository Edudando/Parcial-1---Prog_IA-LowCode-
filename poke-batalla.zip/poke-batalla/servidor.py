"""
servidor.py — Corre Poké Batalla con TU Python (probado con 3.14), sin instalar nada.

    python servidor.py              -> abre http://localhost:8000 en el navegador
    python servidor.py 8080         -> otro puerto
    python servidor.py --no-abrir   -> no abre el navegador

Qué cambia respecto de la versión web (Cloudflare Pages):
- La batalla y los pedidos a PokeAPI los hace este proceso de Python, no Pyodide.
- La página detecta sola el servidor (/api/ping) y no descarga Pyodide: carga al instante.
- La caché de PokeAPI se guarda en la carpeta .cache_pokeapi/ (se puede borrar).
- Cada pestaña tiene su propia partida, así que pueden jugar varias personas en la misma red
  entrando a http://IP-DE-TU-COMPU:8000 (cada una contra la CPU).

Solo usa la biblioteca estándar: http.server + asyncio + urllib.
"""
import asyncio
import json
import os
import platform
import sys
import threading
import uuid
import webbrowser
from collections import OrderedDict
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

RAIZ = os.path.dirname(os.path.abspath(__file__))
PUBLICO = os.path.join(RAIZ, "public")
sys.path.insert(0, PUBLICO)

import pokeapi                      # noqa: E402
from battle import Batalla          # noqa: E402
from main import _publico, resolver_id  # noqa: E402

MAX_PARTIDAS = 200

# Un único event loop de asyncio en un hilo aparte: los pedidos HTTP le mandan corrutinas.
_loop = asyncio.new_event_loop()
threading.Thread(target=_loop.run_forever, daemon=True, name="asyncio").start()


def correr(corrutina, timeout=120):
    return asyncio.run_coroutine_threadsafe(corrutina, _loop).result(timeout)


_partidas = OrderedDict()   # id -> Batalla
_candado = threading.Lock()


# ------------------------------------------------------------------ API
def api_ping(_):
    return {"modo": "local", "python": platform.python_version()}


def api_especies(_):
    return correr(pokeapi.lista_especies())


def api_pokemon(datos):
    try:
        ident = correr(resolver_id(datos.get("texto", "")))
        return _publico(correr(pokeapi.pokemon(ident)))
    except pokeapi.NoEncontrado as e:
        return {"error": str(e)}


def api_nueva(datos):
    ids = datos.get("ids") or []
    if not 1 <= len(ids) <= 6:
        return {"error": "El equipo debe tener entre 1 y 6 Pokémon."}

    async def armar():
        jugador = list(await asyncio.gather(*[pokeapi.preparar(i) for i in ids]))
        return jugador, await pokeapi.equipo_rival(jugador)

    jugador, rival = correr(armar())
    batalla = Batalla(jugador, rival)
    pid = uuid.uuid4().hex
    with _candado:
        _partidas[pid] = batalla
        while len(_partidas) > MAX_PARTIDAS:
            _partidas.popitem(last=False)
    return {**batalla.estado(), "partida": pid}


def api_turno(datos):
    with _candado:
        batalla = _partidas.get(datos.get("partida"))
        if batalla is None:
            return {"error": "La partida no existe (¿se reinició el servidor?). Empezá una nueva."}
        try:
            batalla.jugar_turno(datos.get("accion") or {})
        except ValueError as e:
            return {"error": str(e)}
        return {**batalla.estado(), "partida": datos.get("partida")}


RUTAS = {"/api/ping": api_ping, "/api/especies": api_especies, "/api/pokemon": api_pokemon,
         "/api/nueva": api_nueva, "/api/turno": api_turno}


# ------------------------------------------------------------------ HTTP
class Manejador(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, ".py": "text/plain; charset=utf-8"}

    def _json(self, obj, codigo=200):
        cuerpo = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(cuerpo)

    def _api(self, datos):
        try:
            self._json(RUTAS[self.path](datos))
        except Exception as e:  # sin conexión a PokeAPI, timeout, etc.
            self._json({"error": f"Error en el servidor: {e}"}, 500)

    def do_GET(self):
        if self.path in RUTAS:
            return self._api({})
        return super().do_GET()

    def do_POST(self):
        if self.path not in RUTAS:
            return self._json({"error": "Ruta desconocida"}, 404)
        largo = int(self.headers.get("Content-Length") or 0)
        try:
            datos = json.loads(self.rfile.read(largo) or b"{}")
        except ValueError:
            return self._json({"error": "JSON inválido"}, 400)
        self._api(datos)

    def log_message(self, formato, *args):
        if self.path.startswith("/api/"):   # solo mostramos las llamadas a la API
            sys.stderr.write(f"  {self.command} {self.path}\n")


def principal():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    puerto = int(args[0]) if args else 8000
    servidor = ThreadingHTTPServer(("0.0.0.0", puerto), partial(Manejador, directory=PUBLICO))
    url = f"http://localhost:{puerto}"
    print(f"Poké Batalla con Python {platform.python_version()} -> {url}  (Ctrl+C para cortar)")
    if "--no-abrir" not in sys.argv:
        threading.Timer(0.8, webbrowser.open, args=(url,)).start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")
    finally:
        servidor.server_close()


if __name__ == "__main__":
    principal()
