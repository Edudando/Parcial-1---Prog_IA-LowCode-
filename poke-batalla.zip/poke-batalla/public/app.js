// app.js — Interfaz. La lógica (PokeAPI + batalla) vive en Python: pokeapi.py, battle.py, main.py.
const TAM_EQUIPO = 3;
const DESTACADOS = [25, 6, 9, 3, 94, 143, 130, 149, 448, 282, 445, 658, 384, 150, 887, 1000];
const ARCHIVOS_PY = ["pokeapi.py", "battle.py", "main.py"];

const $ = (sel) => document.querySelector(sel);
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));
const num = (id) => `#${String(id).padStart(4, "0")}`;

const PYODIDE_JS = "https://cdn.jsdelivr.net/pyodide/v0.27.2/full/pyodide.js";

let api = {};            // mismas 4 funciones en los dos modos; todas devuelven objetos
const fichas = new Map(); // id -> datos públicos del Pokémon
let seleccion = [];      // ids elegidos
let estado = null;
let ocupado = false;
let sonido = true;

// ---------- Arranque ----------
// Modo LOCAL: si la página la sirve servidor.py, la batalla la corre el Python de tu compu.
// Modo WEB:   si no (Cloudflare Pages u otro hosting estático), se carga Pyodide en el navegador.
async function detectarServidorLocal() {
  try {
    const r = await fetch("/api/ping", { cache: "no-store" });
    const info = await r.json();           // en hosting estático esto falla (404 o HTML)
    return info.modo === "local" ? info : null;
  } catch {
    return null;
  }
}

async function post(ruta, datos) {
  const r = await fetch(ruta, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(datos),
  });
  return r.json();
}

function apiLocal() {
  let partida = null;
  return {
    especies: () => post("/api/especies", {}),
    pokemon: (texto) => post("/api/pokemon", { texto }),
    nueva: async (ids) => {
      const r = await post("/api/nueva", { ids });
      partida = r.partida;
      return r;
    },
    turno: (accion) => post("/api/turno", { partida, accion }),
  };
}

function cargarScript(src) {
  return new Promise((ok, falla) => {
    const s = document.createElement("script");
    s.src = src;
    s.onload = ok;
    s.onerror = () => falla(new Error(`No se pudo descargar ${src}`));
    document.head.appendChild(s);
  });
}

async function apiPyodide() {
  await cargarScript(PYODIDE_JS);
  const py = await loadPyodide();
  $("#texto-carga").textContent = "Cargando el motor de batalla…";
  for (const nombre of ARCHIVOS_PY) {
    const codigo = await (await fetch(nombre, { cache: "no-cache" })).text();
    py.FS.writeFile(nombre, codigo);
  }
  const main = py.pyimport("main");
  return {
    especies: async () => JSON.parse(await main.api_especies()),
    pokemon: async (texto) => JSON.parse(await main.api_pokemon(texto)),
    nueva: async (ids) => JSON.parse(await main.api_nueva_batalla(JSON.stringify(ids))),
    turno: async (accion) => JSON.parse(main.api_turno(JSON.stringify(accion))),
  };
}

async function iniciar() {
  try {
    const local = await detectarServidorLocal();
    if (local) {
      api = apiLocal();
      $("#modo").textContent = `Python ${local.python} local`;
    } else {
      api = await apiPyodide();
      $("#modo").textContent = "Python en el navegador (Pyodide)";
    }
    mostrar("seleccion");
    cargarDestacados();
    cargarBuscador();
  } catch (err) {
    console.error(err);
    $("#texto-carga").textContent =
      "No se pudo cargar Python en el navegador. Revisá tu conexión y recargá la página.";
  }
}

function mostrar(nombre) {
  document.querySelectorAll(".pantalla").forEach((p) => p.classList.remove("activa"));
  $(`#pantalla-${nombre}`).classList.add("activa");
}

const htmlTipos = (tipos) =>
  `<div class="tipos">${tipos.map((t) => `<span class="tipo t-${t.clave}">${t.nombre}</span>`).join("")}</div>`;

async function pedirPokemon(texto) {
  const r = await api.pokemon(String(texto));
  if (r.error) throw new Error(r.error);
  fichas.set(r.id, r);
  return r;
}

// ---------- Selección ----------
function tarjetaVacia(id) {
  const b = document.createElement("button");
  b.className = "carta cargando";
  b.dataset.id = id;
  b.innerHTML = `<div class="img-ph"></div><div class="num">${num(id)}</div><div class="nombre">…</div>`;
  return b;
}

function llenarTarjeta(b, p) {
  b.className = "carta";
  b.dataset.id = p.id;
  b.innerHTML = `
    <img src="${p.sprites.frente}" alt="${p.nombre}" loading="lazy" />
    <div class="num">${num(p.id)}</div>
    <div class="nombre">${p.nombre}</div>
    ${htmlTipos(p.tipos)}
    <div class="stats">PS ${p.base.ps} · Atq ${Math.max(p.base.atk, p.base.spa)} · Vel ${p.base.spe}<br>Total ${p.total}</div>`;
  b.onclick = () => alternar(p.id);
}

async function cargarDestacados() {
  const grilla = $("#grilla-pokedex");
  grilla.innerHTML = "";
  await Promise.all(DESTACADOS.map(async (id) => {
    const b = tarjetaVacia(id);
    grilla.appendChild(b);
    try { llenarTarjeta(b, await pedirPokemon(id)); }
    catch { b.remove(); }
  }));
  actualizarSeleccion();
}

async function cargarBuscador() {
  try {
    const lista = await api.especies();
    $("#lista-especies").innerHTML = lista.map(([id, n]) => `<option value="${n}">${num(id)}</option>`).join("");
  } catch (e) { console.warn("Sin lista de especies", e); }
}

async function agregarAGrilla(p, elegir) {
  const grilla = $("#grilla-pokedex");
  let b = grilla.querySelector(`.carta[data-id="${p.id}"]`);
  if (!b) {
    b = document.createElement("button");
    llenarTarjeta(b, p);
    b.classList.add("nueva");
    grilla.prepend(b);
  }
  if (elegir && !seleccion.includes(p.id) && seleccion.length < TAM_EQUIPO) seleccion.push(p.id);
  actualizarSeleccion();
  b.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

$("#form-buscar").addEventListener("submit", async (e) => {
  e.preventDefault();
  const texto = $("#input-buscar").value.trim();
  if (!texto) return;
  const msg = $("#msg-buscar");
  msg.className = "msg-buscar";
  msg.textContent = "Buscando en PokeAPI…";
  try {
    const p = await pedirPokemon(texto);
    await agregarAGrilla(p, true);
    msg.textContent = `${p.nombre} agregado${seleccion.includes(p.id) ? " a tu equipo" : " (tu equipo ya está completo)"}.`;
    $("#input-buscar").value = "";
  } catch (err) {
    msg.className = "msg-buscar error";
    msg.textContent = err.message;
  }
});

function alternar(id) {
  const i = seleccion.indexOf(id);
  if (i >= 0) seleccion.splice(i, 1);
  else if (seleccion.length < TAM_EQUIPO) seleccion.push(id);
  actualizarSeleccion();
}

function actualizarSeleccion() {
  document.querySelectorAll(".carta").forEach((c) =>
    c.classList.toggle("elegida", seleccion.includes(Number(c.dataset.id))));
  $("#contador").textContent = `${seleccion.length}/${TAM_EQUIPO}`;
  $("#btn-empezar").disabled = seleccion.length !== TAM_EQUIPO;
  $("#equipo-elegido").innerHTML = seleccion.map((id) => {
    const p = fichas.get(id);
    return p ? `<span class="chip"><img src="${p.sprites.mini}" alt="">${p.nombre}</span>` : "";
  }).join("");
}

$("#btn-azar").addEventListener("click", async () => {
  const btn = $("#btn-azar");
  btn.disabled = true;
  seleccion = [];
  const ids = new Set();
  while (ids.size < TAM_EQUIPO) ids.add(1 + Math.floor(Math.random() * 1025));
  try {
    for (const p of await Promise.all([...ids].map(pedirPokemon))) await agregarAGrilla(p, true);
  } catch (err) {
    $("#msg-buscar").className = "msg-buscar error";
    $("#msg-buscar").textContent = err.message;
  }
  btn.disabled = false;
});

$("#btn-empezar").addEventListener("click", async () => {
  $("#modal-cargando").hidden = false;
  $("#texto-cargando-batalla").textContent = "Descargando movimientos y armando al rival desde PokeAPI…";
  let r;
  try { r = await api.nueva(seleccion); }
  catch (err) { r = { error: `No se pudo armar la batalla (${err.message}).` }; }
  $("#modal-cargando").hidden = true;
  if (r.error) return alert(r.error);
  estado = r;
  $("#log").innerHTML = "";
  $("#sprite-jugador").dataset.src = "";
  $("#sprite-cpu").dataset.src = "";
  mostrar("batalla");
  renderizar();
  escribirLog(estado.log);
});

$("#btn-revancha").addEventListener("click", () => {
  $("#modal-fin").hidden = true;
  mostrar("seleccion");
});

$("#btn-sonido").addEventListener("click", () => {
  sonido = !sonido;
  $("#btn-sonido").textContent = sonido ? "🔊" : "🔇";
});

function gritar(p) {
  if (!sonido || !p.grito) return;
  const a = new Audio(p.grito);
  a.volume = 0.25;
  a.play().catch(() => {});
}

// ---------- Batalla ----------
document.querySelectorAll(".tab").forEach((t) =>
  t.addEventListener("click", () => cambiarTab(t.dataset.tab)));

function cambiarTab(nombre) {
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("activa", t.dataset.tab === nombre));
  $("#panel-movs").classList.toggle("activa", nombre === "movs");
  $("#panel-equipo").classList.toggle("activa", nombre === "equipo");
}

const colorPS = (pct) => (pct > 50 ? "var(--ps-alto)" : pct > 20 ? "var(--ps-medio)" : "var(--ps-bajo)");

function cajaInfo(p, mostrarNumeros) {
  const pct = Math.max(0, (p.ps / p.ps_max) * 100);
  const est = p.estado ? `<span class="estado ${p.estado}">${p.estado}</span>` : "";
  return `
    <div class="fila"><span class="nombre">${p.nombre}${est}</span><span class="nivel">Nv. 50</span></div>
    ${htmlTipos(p.tipos)}
    <div class="barra"><div style="width:${pct}%;background:${colorPS(pct)}"></div></div>
    ${mostrarNumeros ? `<div class="ps-num">${p.ps} / ${p.ps_max}</div>` : ""}`;
}

function ponerSprite(img, url, p) {
  if (img.dataset.src === url) return;
  img.src = url;
  img.dataset.src = url;
  img.alt = p.nombre;
  gritar(p);
}

function renderizar() {
  const jug = estado.jugador.equipo[estado.jugador.activo];
  const cpu = estado.cpu.equipo[estado.cpu.activo];

  ponerSprite($("#sprite-jugador"), jug.sprites.espalda, jug);
  ponerSprite($("#sprite-cpu"), cpu.sprites.frente, cpu);
  $("#sprite-jugador").classList.toggle("debil", !jug.vivo);
  $("#sprite-cpu").classList.toggle("debil", !cpu.vivo);

  $("#info-jugador").innerHTML = cajaInfo(jug, true);
  $("#info-cpu").innerHTML = cajaInfo(cpu, false);
  $("#bolas-cpu").innerHTML = estado.cpu.equipo
    .map((p) => `<span class="bola ${p.vivo ? "" : "fuera"}"></span>`).join("");

  // Movimientos
  const pm = $("#panel-movs");
  pm.innerHTML = "";
  const forzado = estado.cambio_forzado;
  const sinPP = jug.movimientos.every((m) => m.pp === 0);
  jug.movimientos.forEach((m, i) => {
    const b = document.createElement("button");
    b.className = `mov t-${m.tipo.clave}`;
    b.disabled = ocupado || forzado || !!estado.ganador || (m.pp === 0 && !sinPP);
    b.innerHTML = `
      <span class="m-nombre">${m.nombre}</span>
      <span class="m-detalle">${m.tipo.nombre} · ${m.categoria === "fisico" ? "Físico" : "Especial"} · Pot ${m.poder}${m.precision ? ` · Prec ${m.precision}` : ""}</span>
      ${m.efecto ? `<span class="m-efecto">${m.efecto}</span>` : ""}
      <span class="m-detalle">PP ${m.pp}/${m.pp_max}</span>`;
    b.addEventListener("click", () => accion({ tipo: "movimiento", indice: i }));
    pm.appendChild(b);
  });

  // Equipo
  const pe = $("#panel-equipo");
  pe.innerHTML = forzado ? `<p class="aviso">Tu Pokémon se debilitó: elegí el siguiente.</p>` : "";
  estado.jugador.equipo.forEach((p, i) => {
    const b = document.createElement("button");
    const esActivo = i === estado.jugador.activo;
    b.className = `poke-btn ${esActivo ? "activo" : ""}`;
    b.disabled = ocupado || !!estado.ganador || !p.vivo || esActivo;
    const est = p.estado ? ` · ${p.estado}` : "";
    b.innerHTML = `
      <img src="${p.sprites.mini}" alt="" />
      <span><strong>${p.nombre}</strong><br><span class="mini-ps">${p.vivo ? `PS ${p.ps}/${p.ps_max}${est}` : "Debilitado"}</span></span>`;
    b.addEventListener("click", () => accion({ tipo: "cambio", indice: i }));
    pe.appendChild(b);
  });

  cambiarTab(forzado ? "equipo" : document.querySelector(".tab.activa")?.dataset.tab || "movs");
}

function claseLinea(t) {
  if (t.includes("súper eficaz")) return "eficaz";
  if (t.includes("No es muy eficaz") || t.includes("No afecta")) return "poco";
  if (t.includes("se debilitó") || t.includes("Perdiste")) return "debilitado";
  return "";
}

async function escribirLog(lineas, turno) {
  const log = $("#log");
  if (turno) {
    const h = document.createElement("p");
    h.className = "turno";
    h.textContent = `— Turno ${turno} —`;
    log.appendChild(h);
  }
  for (const linea of lineas) {
    const p = document.createElement("p");
    p.className = claseLinea(linea);
    p.textContent = linea;
    log.appendChild(p);
    log.scrollTop = log.scrollHeight;
    if (linea.includes("perdió") && linea.includes("PS")) {
      const s = $(linea.includes(" rival perdió") ? "#sprite-cpu" : "#sprite-jugador");
      s.classList.remove("golpe"); void s.offsetWidth; s.classList.add("golpe");
    }
    await esperar(turno ? 380 : 120);
  }
}

async function accion(acc) {
  if (ocupado) return;
  ocupado = true;
  const turnoAntes = estado.turno;
  const eraCambioForzado = estado.cambio_forzado;
  renderizar();

  let r;
  try { r = await api.turno(acc); }
  catch (err) { r = { error: `Se perdió la conexión con el motor (${err.message}).` }; }
  if (r.error) {
    ocupado = false;
    renderizar();
    return alert(r.error);
  }
  await escribirLog(r.log, eraCambioForzado ? null : turnoAntes);
  estado = r;
  ocupado = false;
  if (!estado.cambio_forzado) cambiarTab("movs");
  renderizar();

  if (estado.ganador) {
    await esperar(700);
    $("#titulo-fin").textContent =
      estado.ganador === "jugador" ? "¡Ganaste! 🏆" : estado.ganador === "cpu" ? "Perdiste…" : "¡Empate!";
    $("#modal-fin").hidden = false;
  }
}

iniciar();
