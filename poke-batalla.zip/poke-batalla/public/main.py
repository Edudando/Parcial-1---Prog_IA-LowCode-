"""
main.py — Puente entre la interfaz (app.js) y Python. Entrada/salida en JSON.

Por consola (usa PokeAPI de verdad, o el espejo si no hay acceso):
    python main.py                 -> una batalla aleatoria con el log completo
    python main.py 50              -> 50 batallas y estadísticas
    python main.py 1 pikachu 6 94  -> tu equipo (nombres o números)
"""
import asyncio
import json
import random
import sys

import pokeapi
from battle import Batalla, _tipos_dict

_BATALLA = None


def _error(e):
    return json.dumps({"error": str(e)}, ensure_ascii=False)


def _publico(p):
    """Lo que necesita la tarjeta del selector."""
    return {"id": p["id"], "clave": p["clave"], "nombre": p["nombre"],
            "tipos": _tipos_dict(p["tipos"]), "base": p["base"],
            "total": pokeapi.total_base(p), "sprites": p["sprites"]}


async def resolver_id(texto):
    """Acepta número ('25'), nombre en inglés ('pikachu') o parte del nombre."""
    texto = str(texto).strip().lower().replace(" ", "-")
    if texto.isdigit():
        return int(texto)
    especies = await pokeapi.lista_especies()
    for i, nombre in especies:
        if nombre == texto:
            return i
    for i, nombre in especies:
        if nombre.startswith(texto):
            return i
    raise pokeapi.NoEncontrado(f"No encontré ningún Pokémon llamado «{texto}».")


# ---------------- funciones que llama app.js ----------------
async def api_especies():
    return json.dumps(await pokeapi.lista_especies())


async def api_pokemon(texto):
    try:
        return json.dumps(_publico(await pokeapi.pokemon(await resolver_id(texto))), ensure_ascii=False)
    except pokeapi.NoEncontrado as e:
        return _error(e)
    except Exception as e:
        return _error(f"No se pudo conectar con PokeAPI ({e}).")


async def api_nueva_batalla(ids_json):
    global _BATALLA
    try:
        ids = json.loads(ids_json)
        if not 1 <= len(ids) <= 6:
            return _error("El equipo debe tener entre 1 y 6 Pokémon.")
        jugador = list(await asyncio.gather(*[pokeapi.preparar(i) for i in ids]))
        rival = await pokeapi.equipo_rival(jugador)
        _BATALLA = Batalla(jugador, rival)
        return json.dumps(_BATALLA.estado(), ensure_ascii=False)
    except Exception as e:
        return _error(f"No se pudo armar la batalla ({e}).")


def api_turno(accion_json):
    if _BATALLA is None:
        return _error("No hay batalla en curso.")
    try:
        _BATALLA.jugar_turno(json.loads(accion_json))
        return json.dumps(_BATALLA.estado(), ensure_ascii=False)
    except ValueError as e:
        return _error(e)


# ---------------- simulación por consola ----------------
async def _simular(n, equipo):
    rng = random.Random(7)
    resultados = {"jugador": 0, "cpu": 0, "empate": 0}
    for s in range(n):
        ids = [await resolver_id(x) for x in equipo] if equipo else rng.sample(range(1, 1026), 3)
        jugador = list(await asyncio.gather(*[pokeapi.preparar(i) for i in ids]))
        rival = await pokeapi.equipo_rival(jugador, rng=random.Random(s))
        b = Batalla(jugador, rival, seed=s)
        registro = list(b.log)
        for _ in range(500):
            if b.ganador:
                break
            if b.cambio_forzado:
                vivos = [i for i, p in enumerate(b.equipos["jugador"]) if p.vivo]
                b.jugar_turno({"tipo": "cambio", "indice": rng.choice(vivos)})
            else:
                p = b.poke("jugador")
                usables = [i for i, m in enumerate(p.movs) if m["pp"] > 0] or [0]
                b.jugar_turno({"tipo": "movimiento", "indice": rng.choice(usables)})
            registro += b.log
        resultados[b.ganador or "empate"] += 1
        if n == 1:
            for lado in ("jugador", "cpu"):
                print(f"== {lado} ==")
                for p in b.equipos[lado]:
                    movs = ", ".join(m["info"]["nombre"] for m in p.movs)
                    print(f"  #{p.id} {p.nombre} {p.tipos} PS {p.ps_max} -> {movs}")
            print("\n".join(registro))
    print(f"\n{n} batalla(s): {resultados} | pedidos HTTP: {pokeapi._pedidos}"
          f" | fuente: {'espejo GitHub' if pokeapi.usar_espejo else 'pokeapi.co'}")


if __name__ == "__main__" and sys.platform != "emscripten":
    cantidad = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    asyncio.run(_simular(cantidad, sys.argv[2:]))
