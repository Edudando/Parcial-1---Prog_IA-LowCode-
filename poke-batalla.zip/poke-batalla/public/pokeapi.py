"""
pokeapi.py — Cliente de PokeAPI (https://pokeapi.co) para el motor de batalla.

- En el navegador (Pyodide) descarga con pyodide.http.pyfetch; en la compu, con urllib.
- Si pokeapi.co no responde, usa automáticamente el espejo oficial en GitHub
  (PokeAPI/api-data), que tiene los mismos JSON. Por eso todo se pide por número.
- Guarda una versión compacta de cada respuesta en memoria y, en el navegador, en
  localStorage: la segunda vez que alguien juega casi no hace pedidos (y cumplimos
  la política de uso justo de PokeAPI, que pide cachear).
"""
import asyncio
import json
import os
import random
import sys

API = "https://pokeapi.co/api/v2"
ESPEJO = "https://raw.githubusercontent.com/PokeAPI/api-data/master/data/api/v2"
MAX_ID = 1025                      # último Pokémon de la Pokédex nacional
PEDIDOS_SIMULTANEOS = 8
VERSION_CACHE = "v1"               # cambiala si modificás el formato compacto
EN_NAVEGADOR = sys.platform == "emscripten"

# Juegos de los que tomamos el set de movimientos, del más nuevo al más viejo.
ORDEN_JUEGOS = [
    "scarlet-violet", "sword-shield", "brilliant-diamond-shining-pearl", "ultra-sun-ultra-moon",
    "sun-moon", "omega-ruby-alpha-sapphire", "x-y", "black-2-white-2", "black-white",
    "heartgold-soulsilver", "platinum", "diamond-pearl", "emerald", "firered-leafgreen",
    "ruby-sapphire", "crystal", "gold-silver", "yellow", "red-blue",
    "lets-go-pikachu-lets-go-eevee", "legends-arceus", "legends-za",
]

# Movimientos con mecánicas que este motor no simula (carga de 2 turnos, recarga,
# autodestrucción, condiciones especiales). Se excluyen para no romper el balance.
EXCLUIDOS = {
    "solar-beam", "solar-blade", "hyper-beam", "giga-impact", "sky-attack", "skull-bash",
    "razor-wind", "fly", "dig", "dive", "bounce", "phantom-force", "shadow-force",
    "meteor-beam", "electro-shot", "frenzy-plant", "blast-burn", "hydro-cannon", "rock-wrecker",
    "roar-of-time", "prismatic-laser", "eternabeam", "explosion", "self-destruct",
    "misty-explosion", "memento", "final-gambit", "dream-eater", "focus-punch", "future-sight",
    "doom-desire", "belch", "last-resort", "fake-out", "first-impression", "synchronoise",
    "steel-beam", "mind-blown", "chloroblast", "freeze-shock", "ice-burn", "sky-drop",
    "geomancy", "sucker-punch", "thunderclap", "upper-hand", "burn-up", "double-shock",
    "hyperspace-fury", "shell-trap", "beak-blast", "spit-up", "natural-gift", "fling",
    "snore", "sleep-talk", "rollout", "ice-ball", "uproar", "outrage", "thrash", "petal-dance",
    "raging-fury", "dynamax-cannon", "behemoth-blade", "behemoth-bash", "struggle",
}

ESTADOS_SOPORTADOS = {"paralysis", "burn", "poison", "sleep", "freeze"}

PLACAJE = {  # por si un Pokémon no tiene ningún ataque de daño (Magikarp, Ditto...)
    "id": 33, "clave": "tackle", "nombre": "Placaje", "tipo": "normal", "cat": "fisico",
    "poder": 40, "prec": 100, "pp": 35, "prioridad": 0, "crit": 0, "min_hits": None,
    "max_hits": None, "drain": 0, "estado": None, "prob_estado": 0, "prob_retroceso": 0,
}

usar_espejo = os.environ.get("POKEAPI_ESPEJO") == "1"
_memoria = {}
_en_curso = {}
_semaforo = None
_pedidos = 0          # cuántos pedidos HTTP se hicieron (para depurar)


class NoEncontrado(Exception):
    pass


# ------------------------------------------------------------------ HTTP
def _url(recurso, ident, espejo):
    if espejo:
        return f"{ESPEJO}/{recurso}/{ident}/index.json" if ident is not None else f"{ESPEJO}/{recurso}/index.json"
    return f"{API}/{recurso}/{ident}/" if ident is not None else f"{API}/{recurso}/?limit=2000"


def _descargar_sync(url):
    import urllib.error
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": "poke-batalla/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise NoEncontrado(url)
        raise


async def _descargar(url):
    global _pedidos
    _pedidos += 1
    if EN_NAVEGADOR:
        from pyodide.http import pyfetch
        r = await pyfetch(url)
        if r.status == 404:
            raise NoEncontrado(url)
        if not r.ok:
            raise IOError(f"HTTP {r.status} en {url}")
        return await r.json()
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _descargar_sync, url)


async def _get(recurso, ident=None):
    """Pide un recurso a pokeapi.co; si falla la conexión, pasa al espejo de GitHub."""
    global usar_espejo, _semaforo
    if _semaforo is None:
        _semaforo = asyncio.Semaphore(PEDIDOS_SIMULTANEOS)
    async with _semaforo:
        if not usar_espejo:
            try:
                return await _descargar(_url(recurso, ident, False))
            except NoEncontrado:
                raise
            except Exception:
                usar_espejo = True
        return await _descargar(_url(recurso, ident, True))


# ------------------------------------------------------------------ caché
def _clave_ls(clave):
    return f"pokeapi:{VERSION_CACHE}:{clave}"


def _archivo_cache(clave):
    # En la compu: una carpeta con un JSON chico por recurso (se puede borrar sin problema)
    carpeta = os.environ.get("POKEAPI_CACHE",
                             os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".cache_pokeapi"))
    return os.path.join(carpeta, VERSION_CACHE, clave.replace(":", "_") + ".json")


def _leer_cache(clave):
    if clave in _memoria:
        return _memoria[clave]
    if not EN_NAVEGADOR:
        try:
            with open(_archivo_cache(clave), encoding="utf-8") as f:
                _memoria[clave] = json.load(f)
                return _memoria[clave]
        except (OSError, ValueError):
            return None
    if EN_NAVEGADOR:
        try:
            from js import localStorage
            v = localStorage.getItem(_clave_ls(clave))
            if v:
                _memoria[clave] = json.loads(v)
                return _memoria[clave]
        except Exception:
            pass
    return None


def _guardar_cache(clave, valor):
    _memoria[clave] = valor
    if not EN_NAVEGADOR:
        try:
            ruta = _archivo_cache(clave)
            os.makedirs(os.path.dirname(ruta), exist_ok=True)
            with open(ruta, "w", encoding="utf-8") as f:
                json.dump(valor, f, ensure_ascii=False)
        except OSError:
            pass
    if EN_NAVEGADOR:
        try:
            from js import localStorage
            localStorage.setItem(_clave_ls(clave), json.dumps(valor, ensure_ascii=False))
        except Exception:
            pass  # localStorage lleno o bloqueado: seguimos solo con memoria


async def _memo(clave, cargar):
    """Devuelve de caché o carga una sola vez (aunque lo pidan varios a la vez)."""
    valor = _leer_cache(clave)
    if valor is not None:
        return valor
    if clave not in _en_curso:
        _en_curso[clave] = asyncio.ensure_future(cargar())
    try:
        valor = await _en_curso[clave]
    finally:
        _en_curso.pop(clave, None)
    _guardar_cache(clave, valor)
    return valor


# ------------------------------------------------------------------ utilidades
def _id_de_url(url):
    return int(url.rstrip("/").split("/")[-1])


def _nombre_es(nombres, defecto):
    for n in nombres:
        if n["language"]["name"] == "es":
            return n["name"]
    return defecto.replace("-", " ").title()


def total_base(p):
    return sum(p["base"].values())


# ------------------------------------------------------------------ recursos
async def lista_especies():
    """[[id, clave_en_ingles], ...] de los 1025 Pokémon, para el buscador."""
    async def cargar():
        d = await _get("pokemon-species")
        return sorted([[_id_de_url(r["url"]), r["name"]] for r in d["results"]
                       if _id_de_url(r["url"]) <= MAX_ID])
    return await _memo("especies", cargar)


async def pokemon(ident):
    """Resumen compacto de un Pokémon: nombre en español, tipos, stats, sprites y movimientos."""
    ident = int(ident)
    if not 1 <= ident <= MAX_ID:
        raise NoEncontrado(f"No existe el Pokémon #{ident}")

    async def cargar():
        p, esp = await asyncio.gather(_get("pokemon", ident), _get("pokemon-species", ident))
        st = {s["stat"]["name"]: s["base_stat"] for s in p["stats"]}
        spr = p["sprites"]
        showdown = (spr.get("other") or {}).get("showdown") or {}
        artwork = ((spr.get("other") or {}).get("official-artwork") or {}).get("front_default")
        frente = showdown.get("front_default") or spr.get("front_default") or artwork
        espalda = showdown.get("back_default") or spr.get("back_default") or frente

        # Set de movimientos del juego más nuevo en que aparece
        por_juego = {}
        for m in p["moves"]:
            mid = _id_de_url(m["move"]["url"])
            for d in m["version_group_details"]:
                juego = d["version_group"]["name"]
                metodo = d["move_learn_method"]["name"]
                por_juego.setdefault(juego, {"nivel": set(), "otros": set()})
                por_juego[juego]["nivel" if metodo == "level-up" else "otros"].add(mid)
        juegos = [j for j in ORDEN_JUEGOS if j in por_juego and por_juego[j]["nivel"]]
        juegos += [j for j in por_juego if j not in juegos]
        elegido = por_juego[juegos[0]] if juegos else {"nivel": set(), "otros": set()}

        return {
            "id": p["id"],
            "clave": p["name"],
            "nombre": _nombre_es(esp["names"], p["name"]),
            "tipos": [t["type"]["name"] for t in sorted(p["types"], key=lambda t: t["slot"])],
            "base": {"ps": st["hp"], "atk": st["attack"], "def": st["defense"],
                     "spa": st["special-attack"], "spd": st["special-defense"], "spe": st["speed"]},
            "sprites": {"frente": frente, "espalda": espalda, "mini": spr.get("front_default") or frente},
            "grito": (p.get("cries") or {}).get("latest"),
            "movs_nivel": sorted(elegido["nivel"]),
            "movs_otros": sorted(elegido["otros"] - elegido["nivel"]),
        }
    return await _memo(f"pokemon:{ident}", cargar)


async def movimiento(mid):
    async def cargar():
        m = await _get("move", mid)
        meta = m.get("meta") or {}
        clase = (m.get("damage_class") or {}).get("name", "status")
        ailment = (meta.get("ailment") or {}).get("name")
        return {
            "id": m["id"], "clave": m["name"],
            "nombre": _nombre_es(m.get("names", []), m["name"]),
            "tipo": m["type"]["name"],
            "cat": {"physical": "fisico", "special": "especial"}.get(clase, "estado"),
            "poder": m.get("power"),
            "prec": m.get("accuracy"),            # None = no falla nunca
            "pp": m.get("pp") or 5,
            "prioridad": m.get("priority") or 0,
            "crit": meta.get("crit_rate") or 0,
            "min_hits": meta.get("min_hits"),
            "max_hits": meta.get("max_hits"),
            "drain": meta.get("drain") or 0,      # >0 roba vida, <0 daño de retroceso
            "estado": ailment if ailment in ESTADOS_SOPORTADOS else None,
            "prob_estado": meta.get("ailment_chance") or 0,
            "prob_retroceso": meta.get("flinch_chance") or 0,
            "meta_cat": (meta.get("category") or {}).get("name"),
        }
    return await _memo(f"move:{mid}", cargar)


def _es_util(m):
    return (m["cat"] != "estado" and m["poder"] and m["poder"] > 1
            and m["clave"] not in EXCLUIDOS and m["meta_cat"] != "ohko")


def _puntaje(m, p):
    stat = p["base"]["atk"] if m["cat"] == "fisico" else p["base"]["spa"]
    golpes = (m["min_hits"] + m["max_hits"]) / 2 if m["min_hits"] else 1
    stab = 1.5 if m["tipo"] in p["tipos"] else 1.0
    prec = (m["prec"] or 100) / 100
    castigo = 1 + min(0, m["drain"]) / 150        # el retroceso resta un poco
    return m["poder"] * golpes * stab * prec * stat * castigo


def elegir_movimientos(p, movs, n=4):
    """Elige 4 ataques: el mejor de cada tipo propio (STAB), después cobertura, después relleno."""
    ordenados = sorted({m["clave"]: m for m in movs if _es_util(m)}.values(),
                       key=lambda m: _puntaje(m, p), reverse=True)
    if not ordenados:
        return [dict(PLACAJE)]
    tope = _puntaje(ordenados[0], p)
    elegidos = []
    for t in p["tipos"]:
        mejor = next((m for m in ordenados if m["tipo"] == t and m not in elegidos), None)
        if mejor and len(elegidos) < n:
            elegidos.append(mejor)
    for m in ordenados:
        tipos = {e["tipo"] for e in elegidos}
        if len(elegidos) < n and m["tipo"] not in tipos and _puntaje(m, p) >= 0.45 * tope:
            elegidos.append(m)
    for m in ordenados:  # preferimos variedad de tipos antes que repetir
        if len(elegidos) < n and m["tipo"] not in {e["tipo"] for e in elegidos} \
                and _puntaje(m, p) >= 0.25 * tope:
            elegidos.append(m)
    for m in ordenados:
        if len(elegidos) < n and m not in elegidos:
            elegidos.append(m)
    return elegidos


async def preparar(ident):
    """Pokémon listo para pelear: resumen + sus 4 movimientos (con datos completos de la API)."""
    p = dict(await pokemon(ident))
    movs = list(await asyncio.gather(*[movimiento(i) for i in p["movs_nivel"]]))
    utiles = [m for m in movs if _es_util(m)]
    # Si con los de nivel hay pocos ataques o poca variedad de tipos, sumamos MT/huevo/tutor
    if (len(utiles) < 4 or len({m["tipo"] for m in utiles}) < 3) and p["movs_otros"]:
        rng = random.Random(p["id"])  # siempre la misma muestra para el mismo Pokémon
        extra = rng.sample(p["movs_otros"], min(30, len(p["movs_otros"])))
        movs += await asyncio.gather(*[movimiento(i) for i in extra])
    p["movs"] = elegir_movimientos(p, movs)
    return p


async def equipo_rival(jugador, rng=None, intentos=6, margen=60):
    """Arma un equipo al azar con poder parecido (suma de stats base) al del jugador."""
    rng = rng or random.Random()
    objetivo = sum(total_base(p) for p in jugador) / len(jugador)
    usados = {p["id"] for p in jugador}

    async def uno():
        mejor = None
        for _ in range(intentos):
            i = rng.randint(1, MAX_ID)
            if i in usados:
                continue
            cand = await pokemon(i)
            dif = abs(total_base(cand) - objetivo)
            if mejor is None or dif < mejor[0]:
                mejor = (dif, cand)
            if dif <= margen:
                break
        usados.add(mejor[1]["id"])
        return mejor[1]["id"]

    ids = []
    for _ in jugador:
        ids.append(await uno())
    return list(await asyncio.gather(*[preparar(i) for i in ids]))
