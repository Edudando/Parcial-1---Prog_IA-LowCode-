"""
battle.py — Motor de batalla Pokémon (mecánicas estilo Gen 6+), alimentado con datos de PokeAPI.

No sabe nada de HTTP: recibe los Pokémon ya preparados por pokeapi.py
(stats base, tipos y movimientos con sus efectos) y resuelve los turnos.
"""
import math
import random

NIVEL = 50

TIPOS_ES = {
    "normal": "Normal", "fire": "Fuego", "water": "Agua", "electric": "Eléctrico",
    "grass": "Planta", "ice": "Hielo", "fighting": "Lucha", "poison": "Veneno",
    "ground": "Tierra", "flying": "Volador", "psychic": "Psíquico", "bug": "Bicho",
    "rock": "Roca", "ghost": "Fantasma", "dragon": "Dragón", "dark": "Siniestro",
    "steel": "Acero", "fairy": "Hada", "stellar": "Astral", "typeless": "???",
}

ESTADOS = {  # clave PokeAPI -> (abreviatura, texto al aplicarse)
    "paralysis": ("PAR", "quedó paralizado. ¡Quizás no pueda moverse!"),
    "burn": ("QUE", "se quemó."),
    "poison": ("ENV", "fue envenenado."),
    "sleep": ("DOR", "se durmió."),
    "freeze": ("CON", "quedó congelado."),
}
INMUNIDADES = {"paralysis": {"electric"}, "burn": {"fire"}, "poison": {"poison", "steel"},
               "freeze": {"ice"}, "sleep": set()}

# Multiplicadores atacante -> defensor (solo los distintos de x1). Tabla Gen 6+.
TABLA_TIPOS = {
    "normal":   {"rock": .5, "ghost": 0, "steel": .5},
    "fire":     {"fire": .5, "water": .5, "grass": 2, "ice": 2, "bug": 2, "rock": .5, "dragon": .5, "steel": 2},
    "water":    {"fire": 2, "water": .5, "grass": .5, "ground": 2, "rock": 2, "dragon": .5},
    "electric": {"water": 2, "electric": .5, "grass": .5, "ground": 0, "flying": 2, "dragon": .5},
    "grass":    {"fire": .5, "water": 2, "grass": .5, "poison": .5, "ground": 2, "flying": .5, "bug": .5,
                 "rock": 2, "dragon": .5, "steel": .5},
    "ice":      {"fire": .5, "water": .5, "grass": 2, "ice": .5, "ground": 2, "flying": 2, "dragon": 2, "steel": .5},
    "fighting": {"normal": 2, "ice": 2, "poison": .5, "flying": .5, "psychic": .5, "bug": .5, "rock": 2,
                 "ghost": 0, "dark": 2, "steel": 2, "fairy": .5},
    "poison":   {"grass": 2, "poison": .5, "ground": .5, "rock": .5, "ghost": .5, "steel": 0, "fairy": 2},
    "ground":   {"fire": 2, "electric": 2, "grass": .5, "poison": 2, "flying": 0, "bug": .5, "rock": 2, "steel": 2},
    "flying":   {"electric": .5, "grass": 2, "fighting": 2, "bug": 2, "rock": .5, "steel": .5},
    "psychic":  {"fighting": 2, "poison": 2, "psychic": .5, "dark": 0, "steel": .5},
    "bug":      {"fire": .5, "grass": 2, "fighting": .5, "poison": .5, "flying": .5, "psychic": 2, "ghost": .5,
                 "dark": 2, "steel": .5, "fairy": .5},
    "rock":     {"fire": 2, "ice": 2, "fighting": .5, "ground": .5, "flying": 2, "bug": 2, "steel": .5},
    "ghost":    {"normal": 0, "psychic": 2, "ghost": 2, "dark": .5},
    "dragon":   {"dragon": 2, "steel": .5, "fairy": 0},
    "dark":     {"fighting": .5, "psychic": 2, "ghost": 2, "dark": .5, "fairy": .5},
    "steel":    {"fire": .5, "water": .5, "electric": .5, "ice": 2, "rock": 2, "steel": .5, "fairy": 2},
    "fairy":    {"fire": .5, "fighting": 2, "poison": .5, "dragon": 2, "dark": 2, "steel": .5},
}

PROB_CRITICO = {0: 1 / 24, 1: 1 / 8, 2: 1 / 2}

FORCEJEO = {"clave": "struggle", "nombre": "Forcejeo", "tipo": "typeless", "cat": "fisico", "poder": 50,
            "prec": None, "pp": 1, "prioridad": 0, "crit": 0, "min_hits": None, "max_hits": None,
            "drain": 0, "estado": None, "prob_estado": 0, "prob_retroceso": 0}


def efectividad(tipo_ataque, tipos_defensor):
    mult = 1.0
    for t in tipos_defensor:
        mult *= TABLA_TIPOS.get(tipo_ataque, {}).get(t, 1.0)
    return mult


def _tipos_dict(tipos):
    return [{"clave": t, "nombre": TIPOS_ES.get(t, t.title())} for t in tipos]


def _calc_ps(base):
    if base == 1:  # Shedinja
        return 1
    return (2 * base + 31) * NIVEL // 100 + NIVEL + 10   # IV 31, EV 0


def _calc_stat(base):
    return (2 * base + 31) * NIVEL // 100 + 5              # naturaleza neutra


class Pokemon:
    def __init__(self, datos):
        b = datos["base"]
        self.datos = datos
        self.id = datos["id"]
        self.nombre = datos["nombre"]
        self.tipos = list(datos["tipos"])
        self.ps_max = _calc_ps(b["ps"])
        self.ps = self.ps_max
        self.stats = {k: _calc_stat(b[k]) for k in ("atk", "def", "spa", "spd", "spe")}
        self.movs = [{"info": m, "pp": m["pp"]} for m in datos["movs"]]
        self.estado = None
        self.turnos_sueno = 0

    @property
    def vivo(self):
        return self.ps > 0

    def velocidad(self):
        return self.stats["spe"] // 2 if self.estado == "paralysis" else self.stats["spe"]

    def sin_pp(self):
        return all(m["pp"] == 0 for m in self.movs)

    def to_dict(self, ocultar_movs=False):
        d = {"id": self.id, "clave": self.datos["clave"], "nombre": self.nombre,
             "tipos": _tipos_dict(self.tipos), "ps": self.ps, "ps_max": self.ps_max,
             "vivo": self.vivo, "sprites": self.datos["sprites"], "grito": self.datos.get("grito"),
             "estado": ESTADOS[self.estado][0] if self.estado else None}
        if not ocultar_movs:
            d["stats"] = dict(self.stats)
            d["movimientos"] = [{
                "nombre": m["info"]["nombre"],
                "tipo": _tipos_dict([m["info"]["tipo"]])[0],
                "categoria": m["info"]["cat"], "poder": m["info"]["poder"],
                "precision": m["info"]["prec"], "pp": m["pp"], "pp_max": m["info"]["pp"],
                "efecto": _describir_efecto(m["info"]),
            } for m in self.movs]
        return d


def _describir_efecto(m):
    partes = []
    if m.get("min_hits"):
        partes.append(f"{m['min_hits']}-{m['max_hits']} golpes" if m["min_hits"] != m["max_hits"]
                      else f"{m['min_hits']} golpes")
    if m.get("drain", 0) > 0:
        partes.append(f"roba {m['drain']}%")
    elif m.get("drain", 0) < 0:
        partes.append(f"retroceso {-m['drain']}%")
    if m.get("estado"):
        prob = m.get("prob_estado") or 100
        partes.append(f"{prob}% {ESTADOS[m['estado']][0]}")
    if m.get("prob_retroceso"):
        partes.append(f"{m['prob_retroceso']}% amedrentar")
    if m.get("prioridad", 0) > 0:
        partes.append(f"prioridad +{m['prioridad']}")
    if m.get("crit", 0) > 0:
        partes.append("crítico alto")
    return " · ".join(partes)


class Batalla:
    def __init__(self, equipo_jugador, equipo_cpu, seed=None):
        self.rng = random.Random(seed)
        if not equipo_jugador or not equipo_cpu:
            raise ValueError("Los dos equipos necesitan al menos un Pokémon.")
        self.equipos = {"jugador": [Pokemon(d) for d in equipo_jugador],
                        "cpu": [Pokemon(d) for d in equipo_cpu]}
        self.activo = {"jugador": 0, "cpu": 0}
        self.turno = 1
        self.ganador = None
        self.cambio_forzado = False
        self._actuaron = set()
        self._amedrentado = set()
        self.log = ["¡El rival te desafía!",
                    f"El rival envió a {self.equipos['cpu'][0].nombre}.",
                    f"¡Adelante, {self.equipos['jugador'][0].nombre}!"]

    # ---------- utilidades ----------
    def poke(self, lado):
        return self.equipos[lado][self.activo[lado]]

    @staticmethod
    def rival(lado):
        return "cpu" if lado == "jugador" else "jugador"

    def etiqueta(self, lado):
        p = self.poke(lado)
        return p.nombre if lado == "jugador" else f"{p.nombre} rival"

    # ---------- daño ----------
    def calcular_danio(self, atacante, defensor, mov):
        if mov["cat"] == "fisico":
            a, d = atacante.stats["atk"], defensor.stats["def"]
        else:
            a, d = atacante.stats["spa"], defensor.stats["spd"]
        ef = 1.0 if mov["tipo"] == "typeless" else efectividad(mov["tipo"], defensor.tipos)
        if ef == 0:
            return 0, 0.0, False
        base = ((2 * NIVEL // 5 + 2) * mov["poder"] * a // d) // 50 + 2
        stab = 1.5 if mov["tipo"] in atacante.tipos else 1.0
        critico = self.rng.random() < PROB_CRITICO.get(mov.get("crit", 0), 1.0)
        quemado = 0.5 if atacante.estado == "burn" and mov["cat"] == "fisico" and not critico else 1.0
        aleatorio = self.rng.uniform(0.85, 1.0)
        danio = math.floor(base * (1.5 if critico else 1.0) * aleatorio * stab * ef * quemado)
        return max(1, danio), ef, critico

    def _cantidad_golpes(self, mov):
        mn, mx = mov.get("min_hits"), mov.get("max_hits")
        if not mn:
            return 1
        if (mn, mx) == (2, 5):  # distribución oficial desde Gen 5: 35/35/15/15
            return self.rng.choices([2, 3, 4, 5], weights=[35, 35, 15, 15])[0]
        return self.rng.randint(mn, mx)

    def _puede_moverse(self, lado):
        p = self.poke(lado)
        if lado in self._amedrentado:
            self.log.append(f"¡{self.etiqueta(lado)} se amedrentó y no pudo moverse!")
            return False
        if p.estado == "sleep":
            if p.turnos_sueno > 0:
                p.turnos_sueno -= 1
                self.log.append(f"{self.etiqueta(lado)} está profundamente dormido.")
                return False
            p.estado = None
            self.log.append(f"¡{self.etiqueta(lado)} se despertó!")
        if p.estado == "freeze":
            if self.rng.random() < 0.2:
                p.estado = None
                self.log.append(f"¡{self.etiqueta(lado)} se descongeló!")
            else:
                self.log.append(f"{self.etiqueta(lado)} está congelado.")
                return False
        if p.estado == "paralysis" and self.rng.random() < 0.25:
            self.log.append(f"¡{self.etiqueta(lado)} está paralizado! No se puede mover.")
            return False
        return True

    def _aplicar_estado(self, lado_def, mov):
        defensor = self.poke(lado_def)
        est = mov.get("estado")
        if not est or not defensor.vivo or defensor.estado:
            return
        if INMUNIDADES[est] & set(defensor.tipos):
            return
        if self.rng.random() * 100 >= (mov.get("prob_estado") or 100):
            return
        defensor.estado = est
        if est == "sleep":
            defensor.turnos_sueno = self.rng.randint(1, 3)
        self.log.append(f"¡{self.etiqueta(lado_def)} {ESTADOS[est][1]}")

    def ejecutar_movimiento(self, lado, idx):
        self._actuaron.add(lado)
        if not self._puede_moverse(lado):
            return
        lado_def = self.rival(lado)
        atacante, defensor = self.poke(lado), self.poke(lado_def)
        if atacante.sin_pp():
            mov = FORCEJEO
            self.log.append(f"¡A {self.etiqueta(lado)} no le quedan movimientos!")
        else:
            slot = atacante.movs[idx]
            slot["pp"] -= 1
            mov = slot["info"]
        self.log.append(f"¡{self.etiqueta(lado)} usó {mov['nombre']}!")

        if mov["prec"] is not None and self.rng.random() * 100 >= mov["prec"]:
            self.log.append("¡Pero falló!")
            return

        antes = defensor.ps
        golpes = self._cantidad_golpes(mov)
        dados, ef, hubo_critico = 0, 1.0, False
        for _ in range(golpes):
            danio, ef, critico = self.calcular_danio(atacante, defensor, mov)
            if ef == 0:
                break
            defensor.ps = max(0, defensor.ps - danio)
            dados += 1
            hubo_critico |= critico
            if not defensor.vivo:
                break
        if ef == 0:
            self.log.append(f"No afecta a {self.etiqueta(lado_def)}...")
            return

        if hubo_critico:
            self.log.append("¡Un golpe crítico!")
        if ef > 1:
            self.log.append("¡Es súper eficaz!")
        elif ef < 1:
            self.log.append("No es muy eficaz...")
        if golpes > 1:
            self.log.append(f"¡Golpeó {dados} {'vez' if dados == 1 else 'veces'}!")
        infligido = antes - defensor.ps
        self.log.append(f"{self.etiqueta(lado_def)} perdió {round(infligido * 100 / defensor.ps_max)}% de sus PS.")

        # Robo de vida / daño de retroceso (campo "drain" de PokeAPI)
        drain = mov.get("drain", 0)
        if mov is FORCEJEO:
            atacante.ps = max(0, atacante.ps - max(1, atacante.ps_max // 4))
            self.log.append(f"{self.etiqueta(lado)} sufrió daño de retroceso.")
        elif drain > 0 and atacante.ps < atacante.ps_max:
            cura = max(1, infligido * drain // 100)
            atacante.ps = min(atacante.ps_max, atacante.ps + cura)
            self.log.append(f"¡{self.etiqueta(lado_def)} perdió energía y {self.etiqueta(lado)} la absorbió!")
        elif drain < 0:
            atacante.ps = max(0, atacante.ps - max(1, infligido * -drain // 100))
            self.log.append(f"{self.etiqueta(lado)} sufrió daño de retroceso.")

        self._aplicar_estado(lado_def, mov)
        if (mov.get("prob_retroceso") and defensor.vivo and lado_def not in self._actuaron
                and self.rng.random() * 100 < mov["prob_retroceso"]):
            self._amedrentado.add(lado_def)

        if not defensor.vivo:
            self.log.append(f"¡{self.etiqueta(lado_def)} se debilitó!")
        if not atacante.vivo:
            self.log.append(f"¡{self.etiqueta(lado)} se debilitó!")

    # ---------- IA del rival ----------
    @staticmethod
    def _puntaje(atacante, defensor, mov):
        ef = efectividad(mov["tipo"], defensor.tipos)
        stab = 1.5 if mov["tipo"] in atacante.tipos else 1.0
        prec = (mov["prec"] or 100) / 100
        golpes = (mov["min_hits"] + mov["max_hits"]) / 2 if mov.get("min_hits") else 1
        if mov["cat"] == "fisico":
            ratio = atacante.stats["atk"] / defensor.stats["def"]
            if atacante.estado == "burn":
                ratio /= 2
        else:
            ratio = atacante.stats["spa"] / defensor.stats["spd"]
        extra = 1.15 if mov.get("estado") and not defensor.estado else 1.0
        return mov["poder"] * golpes * ef * stab * prec * ratio * extra

    def elegir_accion_cpu(self):
        cpu, jug = self.poke("cpu"), self.poke("jugador")
        opciones = [(i, self._puntaje(cpu, jug, m["info"])) for i, m in enumerate(cpu.movs) if m["pp"] > 0]
        if not opciones:
            return {"tipo": "movimiento", "indice": 0}  # forcejeo
        if self.rng.random() < 0.2:  # un poco de imprevisibilidad
            idx = self.rng.choice(opciones)[0]
        else:
            idx = max(opciones, key=lambda o: o[1])[0]
        return {"tipo": "movimiento", "indice": idx}

    def elegir_reemplazo_cpu(self):
        jug = self.poke("jugador")
        vivos = [i for i, p in enumerate(self.equipos["cpu"]) if p.vivo]
        return max(vivos, key=lambda i: max(self._puntaje(self.equipos["cpu"][i], jug, m["info"])
                                             for m in self.equipos["cpu"][i].movs))

    # ---------- flujo del turno ----------
    def cambiar(self, lado, idx):
        if self.poke(lado).vivo:
            if lado == "jugador":
                self.log.append(f"¡{self.poke(lado).nombre}, volvé!")
            else:
                self.log.append(f"El rival retiró a {self.poke(lado).nombre}.")
        self.activo[lado] = idx
        if lado == "jugador":
            self.log.append(f"¡Adelante, {self.poke(lado).nombre}!")
        else:
            self.log.append(f"El rival envió a {self.poke(lado).nombre}.")

    def _validar(self, accion):
        tipo, idx = accion.get("tipo"), accion.get("indice")
        if not isinstance(idx, int):
            raise ValueError("Falta el índice de la acción.")
        if tipo == "movimiento":
            p = self.poke("jugador")
            if not 0 <= idx < len(p.movs):
                raise ValueError("Movimiento inválido.")
            if p.movs[idx]["pp"] == 0 and not p.sin_pp():
                raise ValueError("A ese movimiento no le quedan PP.")
        elif tipo == "cambio":
            equipo = self.equipos["jugador"]
            if not 0 <= idx < len(equipo) or not equipo[idx].vivo or idx == self.activo["jugador"]:
                raise ValueError("No podés cambiar a ese Pokémon.")
        else:
            raise ValueError("Acción desconocida.")

    def jugar_turno(self, accion):
        if self.ganador:
            raise ValueError("La batalla ya terminó.")

        if self.cambio_forzado:
            if accion.get("tipo") != "cambio":
                raise ValueError("Tenés que elegir un Pokémon para seguir.")
            self._validar(accion)
            self.log = []
            self.cambiar("jugador", accion["indice"])
            self.cambio_forzado = False
            return

        self._validar(accion)
        self.log = []
        self._actuaron, self._amedrentado = set(), set()
        acciones = [("jugador", accion), ("cpu", self.elegir_accion_cpu())]

        # 1) Los cambios van siempre primero
        for lado, acc in acciones:
            if acc["tipo"] == "cambio":
                self.cambiar(lado, acc["indice"])
                self._actuaron.add(lado)

        # 2) Movimientos: prioridad, después velocidad (la parálisis la reduce), empate al azar
        def orden(item):
            lado, acc = item
            p = self.poke(lado)
            prio = 0 if p.sin_pp() else p.movs[acc["indice"]]["info"]["prioridad"]
            return (-prio, -p.velocidad(), self.rng.random())

        for lado, acc in sorted([a for a in acciones if a[1]["tipo"] == "movimiento"], key=orden):
            if self.poke(lado).vivo and self.poke(self.rival(lado)).vivo:
                self.ejecutar_movimiento(lado, acc["indice"])

        self._danio_residual()
        self._fin_de_turno()
        self.turno += 1

    def _danio_residual(self):
        for lado in ("jugador", "cpu"):
            p = self.poke(lado)
            if not p.vivo or p.estado not in ("burn", "poison"):
                continue
            frac = 16 if p.estado == "burn" else 8
            p.ps = max(0, p.ps - max(1, p.ps_max // frac))
            causa = "la quemadura" if p.estado == "burn" else "el veneno"
            self.log.append(f"{self.etiqueta(lado)} se resiente por {causa}.")
            if not p.vivo:
                self.log.append(f"¡{self.etiqueta(lado)} se debilitó!")

    def _fin_de_turno(self):
        quedan_j = any(p.vivo for p in self.equipos["jugador"])
        quedan_c = any(p.vivo for p in self.equipos["cpu"])
        if not quedan_j and not quedan_c:
            self.ganador = "empate"
            self.log.append("¡Los dos equipos quedaron fuera de combate! Empate.")
            return
        if not quedan_c:
            self.ganador = "jugador"
            self.log.append("¡Ganaste la batalla!")
            return
        if not quedan_j:
            self.ganador = "cpu"
            self.log.append("Te quedaste sin Pokémon... ¡Perdiste!")
            return
        if not self.poke("cpu").vivo:
            self.cambiar("cpu", self.elegir_reemplazo_cpu())
        if not self.poke("jugador").vivo:
            self.cambio_forzado = True
            self.log.append("Elegí tu próximo Pokémon.")

    def estado(self):
        return {
            "turno": self.turno,
            "ganador": self.ganador,
            "cambio_forzado": self.cambio_forzado,
            "log": list(self.log),
            "jugador": {"activo": self.activo["jugador"],
                        "equipo": [p.to_dict() for p in self.equipos["jugador"]]},
            "cpu": {"activo": self.activo["cpu"],
                    "equipo": [p.to_dict(ocultar_movs=True) for p in self.equipos["cpu"]]},
        }
